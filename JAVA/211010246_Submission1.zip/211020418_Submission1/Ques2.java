class Ques2{
public static void main(String args[]){
          int agekaran=22;
          String result=  (agekaran>=18)?("Eligible"): ("NotEligible");
          System.out.println("Karan You are "+result+" for voter id");
     }
}