// Created by Gaurish Ojha.
import java.util.*;
class AreaRectangle{
     void area1(){
           double total=0;
           for(int i=1;i<=5;i++){
                  Scanner sc=new Scanner(System.in);
                  System.out.println("Enter length and width of the  "+ i +"  rectangle");
                  float l=sc.nextFloat();
                  float b=sc.nextFloat();
                  total=total+(l*b);
                  System.out.println("Area of the  "+ i +"  rectangle is :  "+ l*b);
                }
                  System.out.println("Area of the all 5 rectangle is :  "+ total);//after all 5 rectangle input total area of rectangle
        }
}
class AreaSphere{
   void area2(){
          double total=0;
           for(int i=1;i<=6;i++){
                 Scanner sc=new Scanner(System.in);
                 System.out.println("Enter radius of the  "+ i +"  sphere");
                 float r=sc.nextFloat();
                 System.out.println("Area of the  "+ i +"  sphere is : "+4*(3.14)*r*r);
                 total=total+(4*(3.14)*r*r);
                 }
                  System.out.println("Area of the all 6 sphere is :  "+ total);  //after all 6 sphere input total area of sphere
         }
}
class VolumeCylinder{
   void volume(){
                  System.out.println("volume of cylindrer  :  "+ ((3.14)*1.5*1.5*90)); //volume of cylinder 
         }
}
class Ques1{
      public static void main(String args[]){
       AreaRectangle ans1=new AreaRectangle();
       ans1.area1();
       AreaSphere ans2=new AreaSphere();
       ans2.area2();
      VolumeCylinder ans3=new VolumeCylinder();
       ans3.volume();
      }
}