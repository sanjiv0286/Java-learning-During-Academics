import java.util.*;
public class MobileSaler {
public static void main(String[] args){
int total =4*11+ 13*32 +7*23;
System.out.println("HEY, Here are the REPORTS");
XX.XXse();
XZ.XZse();
XY.XYse();
System.out.println("Total Sales: "+"Rs."+total+"K"+"\n");
}
}
class XX{

static String name ="XX";
static int weight=350 ;
static int price=11;
static int batterypower=3000;
static int ram=4;
static int rom=32;
static int sale=4*11;
static String brand ="Samsung";
static void XXse(){
System.out.println("Series Name : "+name+"\n"+"Weight: "+weight+"gms"+"\n"+"Price: "+"Rs."+price+"K"+"\n"+"Battery: "+batterypower+"mAh"+"\n"+"RAM : "+ram+"GB"+"\n"+"ROM: "+rom+"GB"+"\n"+"Brand: "+brand+"\n"+"Sales: "+"Rs."+sale+"K"+"\n");
}
} 

class XZ{

static String name;
static int weight;
static int price;
static int batterypower;
static int ram;
static int rom;
static int sale;
static String brand;
static {
name ="XZ";
weight=150 ;
price=32;
batterypower=9000;
ram=16;
rom=128;
sale=13*32;
brand ="Samsung";
}
static void XZse(){
System.out.println("Series Name : "+name+"\n"+"Weight: "+weight+"gms"+"\n"+"Price: "+"Rs."+price+"K"+"\n"+"Battery: "+batterypower+"mAh"+"\n"+"RAM : "+ram+"GB"+"\n"+"ROM: "+rom+"GB"+"\n"+"Brand: "+brand+"\n"+"Sales: "+"Rs."+sale+"K"+"\n");
}
} 


class XY{

static String name ="XY";
static int weight=250 ;
static int price=23;
static int batterypower=5000;
static int ram=8;
static int rom=64;
static int sale=7*23;
static String brand ="Samsung";
static void XYse(){
System.out.println("Series Name : "+name+"\n"+"Weight: "+weight+"gms"+"\n"+"Price: "+"Rs."+price+"K"+"\n"+"Battery: "+batterypower+"mAh"+"\n"+"RAM : "+ram+"GB"+"\n"+"ROM: "+rom+"GB"+"\n"+"Brand: "+brand+"\n"+"Sales: "+"Rs."+sale+"K"+"\n");
}
} 
