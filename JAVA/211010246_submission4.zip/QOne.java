import java.util.Scanner;
class QOne{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		Input i1 = new Input();
		System.out.println("Enter Ten Numbers : ");
		for(int x=0;x<10;x++){
			i1.a[x]=sc.nextInt();
		}
		i1.Sum();		
	}
}
class Input{
	int a[]=new int[10];
	int fact=1;
	void Sum(){
		int c=0;
		for(int i=0;i<10;i++){
			
			c=c+a[i];
		}
		System.out.println("Sum is: "+c);
		for(int i=1;i<=c;i++){
			fact*=i;
		}
		System.out.println("FACTORIAL : "+fact);
	}		
}