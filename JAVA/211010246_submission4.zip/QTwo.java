import java.util.Scanner;

class QTwo{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		Arrinp a1=new Arrinp();
		System.out.println("Enter MATRIX : ");
		for(int i=0;i<4;i++){
			for(int j=0;j<4;j++){
				a1.a[i][j]=sc.nextInt();
			}
		}
		a1.sum();
		
	}
}

class Arrinp{
	int a[][]= new int[5][5];
	void sum(){
		int sm=0;
		System.out.println("the elements are:");
		for(int i=0;i<4;i++){
			for(int j=0;j<4;j++){
				if((i==3 && (j==2 || j==3)) || (i==2 && (j==2 || j==3))){
					System.out.println(a[i][j]);
					sm+=a[i][j];
				}
			}
		}
		System.out.println("SUM : "+sm);
		int sm2=0;
		for(int i=1;i<sm;i++){
			if(sm%i==0){
				sm2+=i;
			}
		}
		if(sm2==sm){
			System.out.println("PERFECT  NUMBER");
		}
		else{
			System.out.println("NOT A PERFECT NUMBER");	
		}
	}

}