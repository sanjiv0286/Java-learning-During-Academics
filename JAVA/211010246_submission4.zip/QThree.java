import java.util.Scanner;

class QThree{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		Arrinp a1=new Arrinp();
		System.out.println("MATRIX : ");
		for(int i=0;i<5;i++){
			for(int j=0;j<5;j++){
				a1.a[i][j]=sc.nextInt();
			}
		}
		a1.sum();
		
	}
}

class Arrinp{
	int a[][]= new int[5][5];
	void sum(){
		int sm=0;
		System.out.println("the elements are:");
		for(int i=0;i<5;i++){
			for(int j=0;j<5;j++){
				if((i==0 && (j==0 || j==4)) || (i==4 && (j==0 || j==4))){
					System.out.println(a[i][j]);
					sm+=a[i][j];
				}
			}
		}
		System.out.println("SUM : "+sm);
		
	}

}