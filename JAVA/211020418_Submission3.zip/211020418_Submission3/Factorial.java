// Gaurish Ojha 211020418
import java.util.*;
class Factorial{
       public static void main(String args[]){
             Scanner k=new Scanner(System.in);
             System.out.println("Enter The Number : ");
             int num=k.nextInt();
             int ans=1;
       for(int i=1;i<=num;i++){
              ans=ans*i;
            }
         System.out.println("Factorial Of Given number =  "+ans);
      }
}